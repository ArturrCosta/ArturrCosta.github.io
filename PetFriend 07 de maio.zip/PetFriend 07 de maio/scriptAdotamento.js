/* Função para adicionar e remover borda */
function adicionarBorda(idElemento) {
    const elemento = document.getElementById(idElemento);

    elemento.addEventListener("mouseover", () => {
        elemento.style.border = "1px solid black";
        elemento.style.backgroundColor = "black"
    });

    elemento.addEventListener("mouseout", () => {
        elemento.style.border = "none";
        elemento.style.backgroundColor = "rgb(131, 185, 255)"
    });
}

/* Cachorro */
adicionarBorda("cachorro1");
adicionarBorda("cachorro2");
adicionarBorda("cachorro3");

/* Gato */
adicionarBorda("gato1");
adicionarBorda("gato2");
adicionarBorda("gato3");

/* Coelho */
adicionarBorda("coelho1");
adicionarBorda("coelho2");
adicionarBorda("coelho3");

/* Hamster */
adicionarBorda("hamster1");
adicionarBorda("hamster2");
adicionarBorda("hamster3");

/* Jiboia */
adicionarBorda("jiboia1");
adicionarBorda("jiboia2");
adicionarBorda("jiboia3");

/* Calopsita */
adicionarBorda("calopsita1");
adicionarBorda("calopsita2");
adicionarBorda("calopsita3");
